// packages/dsh-bridge/src/host/cordis-plugin.ts
import { createInterface } from "node:readline";

// packages/dsh-bridge/src/host/create-host.ts
var HOST_PORT_NAMES = [
  "workspaces",
  "sessions",
  "projections",
  "interactions",
  "artifacts",
  "terminals",
  "presets",
  "dynamicRuntime"
];
function createDshHost(options) {
  const { adapter } = options;
  let settledCapabilities = [];
  function operationAvailability(operationId) {
    for (const descriptor of settledCapabilities) {
      if (descriptor.capabilityId === operationId) {
        return { available: true };
      }
    }
    return {
      available: false,
      reason: { code: "CAPABILITY_NOT_NEGOTIATED" }
    };
  }
  return {
    adapterIdentity: adapter.identity,
    capabilities: () => settledCapabilities,
    availability: operationAvailability,
    applyNegotiation(capabilities) {
      settledCapabilities = [...capabilities];
    },
    port(portName) {
      if (!HOST_PORT_NAMES.includes(portName)) {
        throw new Error(`UNKNOWN_HOST_PORT: ${portName}`);
      }
      return adapter[portName];
    },
    async dispose() {
      settledCapabilities = [];
      await adapter.dispose();
    }
  };
}

// packages/dsh-bridge/src/adapters/shared/public-services.ts
function settledServiceNames(ctx, candidates) {
  const lookup = ctx;
  return candidates.filter((name) => lookup[name] !== undefined && lookup[name] !== null);
}
function capability(capabilityId, schemaRevision, mode, stability = "stable") {
  return { capabilityId, schemaRevision, stability, mode };
}
function availabilityFor(capabilities, operationId) {
  if (capabilities.some((descriptor) => descriptor.capabilityId === operationId)) {
    return { available: true };
  }
  return { available: false, reason: { code: "CAPABILITY_NOT_NEGOTIATED" } };
}

// packages/dsh-bridge/src/adapters/rc1.ts
var RC1_SERVICE_EVIDENCE = [
  "typertGateway",
  "typert",
  "sessions",
  "agents",
  "sessionPersistence",
  "sessionProjections",
  "sessionQuery",
  "sessionController",
  "workspaceRegistry",
  "workspaceController",
  "approval",
  "terminals",
  "llm"
];
var RC1_SCHEMA_VERSION = 0;
var RC1_ADAPTER_ID = "aiohub-dsh-rc1";
var RC1_IDENTITY = {
  adapterId: RC1_ADAPTER_ID,
  releaseTag: "dsh-v0.1.2-rc.1",
  releaseCommit: "a66e4702047846cdaa10c66c9d3df3951f5ea70d",
  schemaVersion: RC1_SCHEMA_VERSION,
  serviceEvidence: [...RC1_SERVICE_EVIDENCE]
};

class CapabilityUnavailableError extends Error {
  operationId;
  constructor(operationId) {
    super(`CAPABILITY_UNAVAILABLE: ${operationId}`);
    this.name = "CapabilityUnavailableError";
    this.operationId = operationId;
  }
}
function rc1Capabilities(runtime, schemaRevision) {
  const capabilities = [
    capability("workspace.follow", schemaRevision, "observe"),
    capability("session.open", schemaRevision, "read"),
    capability("session.snapshot", schemaRevision, "read"),
    capability("session.history", schemaRevision, "read"),
    capability("session.subscribe", schemaRevision, "observe"),
    capability("session.submit-prompt", schemaRevision, "mutate"),
    capability("session.cancel", schemaRevision, "mutate"),
    capability("session.list", schemaRevision, "read"),
    capability("interaction.approval", schemaRevision, "mutate"),
    capability("terminal.open", schemaRevision, "mutate"),
    capability("terminal.read", schemaRevision, "read"),
    capability("terminal.send", schemaRevision, "mutate"),
    capability("terminal.close", schemaRevision, "mutate")
  ];
  const optional = [
    [typeof runtime.ctx.workspaceController.create === "function", "workspace.create", "mutate"],
    [typeof runtime.ctx.workspaceController.rename === "function", "workspace.rename", "mutate"],
    [typeof runtime.ctx.workspaceController.delete === "function", "workspace.delete", "mutate"],
    [typeof runtime.ctx.workspaceController.archiveSession === "function", "workspace.archive-session", "mutate"],
    [typeof runtime.ctx.sessionController.create === "function", "session.create", "mutate"],
    [typeof runtime.ctx.sessionController.search === "function", "session.search", "read"],
    [typeof runtime.ctx.sessionController.resolveAgent === "function", "session.resume", "mutate"],
    [typeof runtime.ctx.sessionController.rename === "function" && runtime.ctx.get?.("sessionTitle") !== undefined, "session.rename", "mutate"],
    [typeof runtime.ctx.sessionController.fork === "function", "session.fork", "mutate"],
    [typeof runtime.ctx.sessionController.updateQueue === "function", "session.update-queue", "mutate"],
    [typeof runtime.ctx.sessionController.selectModel === "function", "session.select-model", "mutate"]
  ];
  for (const [available, id, mode] of optional) {
    if (available)
      capabilities.push(capability(id, schemaRevision, mode));
  }
  return capabilities;
}
function requireAvailable(capabilities, operationId) {
  if (!availabilityFor(capabilities, operationId).available) {
    throw new CapabilityUnavailableError(operationId);
  }
}
function mapHistoryRecord(record) {
  if (record.type === "chunks") {
    return { type: record.type };
  }
  return {
    type: record.type,
    ...record.event === undefined ? {} : {
      event: {
        type: record.event.type,
        seq: record.event.seq,
        time: record.event.time,
        data: record.event.data
      }
    }
  };
}
function createRc1Adapter(options) {
  const { runtime } = options;
  const identity = { ...RC1_IDENTITY, serviceEvidence: [...RC1_SERVICE_EVIDENCE] };
  let settledCapabilities = [];
  let disposed = false;
  function requireSettled() {
    if (settledCapabilities.length === 0) {
      throw new Error("rc1 adapter operations require settle() to prove capabilities first");
    }
    return settledCapabilities;
  }
  function basePort(operationId) {
    return {
      __operationId: operationId,
      operationAvailability(otherOperationId) {
        if (disposed) {
          return { available: false, reason: { code: "TEMPORARILY_UNAVAILABLE" } };
        }
        return availabilityFor(settledCapabilities, otherOperationId);
      }
    };
  }
  function sessionOwner(sessionId) {
    return runtime.ctx.sessions.get(sessionId);
  }
  const workspaces = {
    ...basePort("workspace.create"),
    async create(input) {
      requireAvailable(requireSettled(), "workspace.create");
      const value = await runtime.ctx.workspaceController.create({ path: input.path });
      return { ...value.workspace, created: value.created };
    },
    async follow() {
      requireAvailable(requireSettled(), "workspace.follow");
      return runtime.ctx.workspaceController.follow(new AbortController().signal);
    },
    async rename(input) {
      requireAvailable(requireSettled(), "workspace.rename");
      const value = await runtime.ctx.workspaceController.rename(input);
      return value.workspace;
    },
    async delete(input) {
      requireAvailable(requireSettled(), "workspace.delete");
      return runtime.ctx.workspaceController.delete(input);
    },
    async archiveSession(input) {
      requireAvailable(requireSettled(), "workspace.archive-session");
      return runtime.ctx.workspaceController.archiveSession(input);
    }
  };
  const sessions = {
    ...basePort("session.create"),
    async create(input) {
      requireAvailable(requireSettled(), "session.create");
      return runtime.ctx.sessionController.create({
        ...input.cwd === undefined ? {} : { cwd: input.cwd },
        ...input.workspaceId === undefined ? {} : { workspaceId: input.workspaceId },
        ...input.sessionId === undefined ? {} : { sessionId: input.sessionId },
        ...input.agentPreset === undefined ? {} : { agentPreset: input.agentPreset }
      });
    },
    async open(input) {
      requireAvailable(requireSettled(), "session.open");
      const inspection = await runtime.ctx.sessionController.inspect(input.sessionId);
      return { header: inspection.meta, events: inspection.events };
    },
    async snapshot(input) {
      requireAvailable(requireSettled(), "session.snapshot");
      const signal = new AbortController;
      const iterator = runtime.ctx.sessionController.follow({ address: { kind: "session", sessionId: input.sessionId } }, signal.signal)[Symbol.asyncIterator]();
      const first = await iterator.next();
      signal.abort();
      iterator.next().catch(() => {
        return;
      });
      if (first.done || first.value.type !== "snapshot") {
        throw new Error("rc1 session snapshot: follow did not open with a snapshot frame");
      }
      return {
        type: "snapshot",
        header: first.value.header,
        cursor: first.value.cursor,
        records: first.value.records.map((record) => mapHistoryRecord(record)),
        hasMore: first.value.hasMore,
        projections: first.value.projections
      };
    },
    async history(input, signal = new AbortController().signal) {
      requireAvailable(requireSettled(), "session.history");
      const page = await runtime.ctx.sessionController.page({
        address: { kind: "session", sessionId: input.sessionId },
        throughSeq: input.throughSeq,
        ...input.beforeSeq === undefined ? {} : { beforeSeq: input.beforeSeq },
        ...input.maxMessages === undefined ? {} : { maxMessages: input.maxMessages }
      }, signal);
      return { records: page.records.map((record) => mapHistoryRecord(record)), hasMore: page.hasMore };
    },
    async subscribe(input) {
      requireAvailable(requireSettled(), "session.subscribe");
      return runtime.ctx.sessionController.follow({ address: { kind: "session", sessionId: input.sessionId } }, new AbortController().signal);
    },
    async submitPrompt(input) {
      requireAvailable(requireSettled(), "session.submit-prompt");
      const value = await runtime.ctx.sessionController.prompt({
        requestId: input.requestId,
        sessionId: input.sessionId,
        mode: input.mode ?? "queue",
        content: input.content
      }, new AbortController().signal);
      return { accepted: value.accepted };
    },
    async cancel(input) {
      requireAvailable(requireSettled(), "session.cancel");
      return runtime.ctx.sessionController.cancel({ sessionId: input.sessionId });
    },
    async list() {
      requireAvailable(requireSettled(), "session.list");
      const value = await runtime.ctx.sessionController.list({}, new AbortController().signal);
      return value.items;
    },
    async search(input, signal = new AbortController().signal) {
      requireAvailable(requireSettled(), "session.search");
      return runtime.ctx.sessionController.search(input, signal);
    },
    async resume(input) {
      requireAvailable(requireSettled(), "session.resume");
      return runtime.ctx.sessionController.resolveAgent(input.sessionId);
    },
    async rename(input) {
      requireAvailable(requireSettled(), "session.rename");
      return runtime.ctx.sessionController.rename(input);
    },
    async fork(input) {
      requireAvailable(requireSettled(), "session.fork");
      return runtime.ctx.sessionController.fork(input);
    },
    async updateQueue(input) {
      requireAvailable(requireSettled(), "session.update-queue");
      return runtime.ctx.sessionController.updateQueue(input);
    },
    async selectModel(input) {
      requireAvailable(requireSettled(), "session.select-model");
      return runtime.ctx.sessionController.selectModel(input);
    }
  };
  const interactions = {
    ...basePort("interaction.approval"),
    async resolveApproval(input) {
      requireAvailable(requireSettled(), "interaction.approval");
      const owner = sessionOwner(input.sessionId);
      if (owner === undefined) {
        throw new Error(`rc1 interaction: session "${input.sessionId}" is not attached`);
      }
      const outcome = input.decision === "allow-once" ? "allowed-once" : "rejected";
      const unregister = runtime.ctx.on("approval/request", () => Promise.resolve(outcome));
      try {
        const agent = runtime.ctx.agents.get(input.sessionId) ?? owner;
        const resolved = await runtime.ctx.approval.request({ agent, toolName: input.toolName });
        return { outcome: resolved, correlationId: `${input.sessionId}:${input.toolName}` };
      } finally {
        unregister();
      }
    }
  };
  const terminals = {
    ...basePort("terminal.open"),
    async open(input) {
      requireAvailable(requireSettled(), "terminal.open");
      const owner = sessionOwner(input.sessionId);
      if (owner === undefined) {
        throw new Error(`rc1 terminal: session "${input.sessionId}" is not attached`);
      }
      const agent = runtime.ctx.agents.get(input.sessionId) ?? owner;
      const value = await runtime.ctx.terminals.spawn(agent, { type: input.type ?? "fixture-pty", ...input.name === undefined ? {} : { name: input.name } });
      return { handleId: value.sessionId, motd: value.motd, status: value.status };
    },
    async read(input) {
      requireAvailable(requireSettled(), "terminal.read");
      const agent = runtime.ctx.agents.get(input.sessionId) ?? sessionOwner(input.sessionId);
      const value = runtime.ctx.terminals.read(agent, input.handleId);
      return { text: value.text, totalLines: value.totalLines, truncated: value.truncated };
    },
    async send(input) {
      requireAvailable(requireSettled(), "terminal.send");
      const agent = runtime.ctx.agents.get(input.sessionId) ?? sessionOwner(input.sessionId);
      const operation = runtime.ctx.terminals.startSend(agent, input.handleId, { text: input.text, submit: input.submit });
      return await operation.done;
    },
    async close(input) {
      requireAvailable(requireSettled(), "terminal.close");
      const agent = runtime.ctx.agents.get(input.sessionId) ?? sessionOwner(input.sessionId);
      return { closed: await runtime.ctx.terminals.kill(agent, input.handleId, "host close") };
    },
    list(input) {
      requireAvailable(requireSettled(), "terminal.open");
      const agent = runtime.ctx.agents.get(input.sessionId) ?? sessionOwner(input.sessionId);
      return runtime.ctx.terminals.list(agent).map((snapshot) => ({
        handleId: snapshot.sessionId,
        type: snapshot.type,
        status: snapshot.status
      }));
    }
  };
  const projections = {
    ...basePort("projections")
  };
  const artifacts = {
    ...basePort("artifacts")
  };
  const presets = {
    ...basePort("presets")
  };
  const dynamicRuntime = {
    ...basePort("dynamicRuntime")
  };
  return {
    identity,
    async probe() {
      if (disposed) {
        return { ok: false, schemaVersion: RC1_SCHEMA_VERSION, services: [], capabilities: [] };
      }
      const services = settledServiceNames(runtime.ctx, RC1_SERVICE_EVIDENCE);
      const ok = RC1_SERVICE_EVIDENCE.every((service) => services.includes(service));
      return {
        ok,
        schemaVersion: RC1_SCHEMA_VERSION,
        services,
        capabilities: ok ? rc1Capabilities(runtime, RC1_SCHEMA_VERSION) : []
      };
    },
    async settle() {
      const probe = await this.probe();
      if (!probe.ok) {
        throw new Error(`rc1 adapter settle failed: missing services ${RC1_SERVICE_EVIDENCE.filter((service) => !probe.services.includes(service)).join(", ")}`);
      }
      settledCapabilities = probe.capabilities;
      return { schemaVersion: probe.schemaVersion, capabilities: [...probe.capabilities] };
    },
    workspaces,
    sessions,
    projections,
    interactions,
    artifacts,
    terminals,
    presets,
    dynamicRuntime,
    async migrate(_input) {
      return { status: "not-migrated", reason: { code: "CAPABILITY_NOT_NEGOTIATED" } };
    },
    async dispose() {
      disposed = true;
      settledCapabilities = [];
    }
  };
}

// packages/dsh-bridge/src/presenters/mask.ts
function maskValue(value) {
  if (Array.isArray(value))
    return value.map(maskValue);
  if (typeof value !== "object" || value === null) {
    return typeof value === "string" ? maskText(value) : value;
  }
  return Object.fromEntries(Object.entries(value).map(([key, child]) => {
    if (/api[_-]?key|token|secret|password/i.test(key))
      return [key, "***"];
    return [key, maskValue(child)];
  }));
}
function maskText(value) {
  return value.replace(/\b[A-Za-z]:\\[^\s"'<>|]+/g, "<path>").replace(/((?:api[_-]?key|token|secret|password)\s*[:=]\s*)[^\s,;]+/gi, "$1***");
}

// packages/dsh-bridge/src/projections/snapshot.ts
var DURABLE_KINDS = /^(?:turn\/(?:start|complete|error|cancelled|interrupted)|user\/message|assistant\/message|tool\/(?:call|result)|artifact\/|approval\/(?:asked|decided)|question\/(?:asked|answered)|terminal\/(?:opened|closed|exited)|job\/(?:started|completed|failed)|subagent\/(?:started|completed|failed))/;
function createAuthoritativeSnapshot(input) {
  const durableFacts = [];
  for (const record of input.value.records) {
    const event = record.event;
    if (record.type !== "event" || event === undefined || !DURABLE_KINDS.test(event.type)) {
      continue;
    }
    if (event.type === "user/message" && isInjectedContext(event.data))
      continue;
    const data = event.data;
    const turnId = typeof data === "object" && data !== null && "turnId" in data && typeof data.turnId === "string" ? data.turnId : undefined;
    durableFacts.push({
      kind: event.type,
      sessionId: input.sessionId,
      ...turnId === undefined ? {} : { turnId },
      data: maskValue(data)
    });
  }
  if (durableFacts.length === 0) {
    throw new Error("DSH snapshot contains no durable facts");
  }
  return {
    contractHash: input.contractHash,
    source: "dsh",
    provenance: {
      adapterId: input.adapterId,
      ...input.releaseCommit === undefined ? {} : { releaseCommit: input.releaseCommit }
    },
    domainGenerationId: input.domainGenerationId,
    sessionId: input.sessionId,
    cursor: `cursor-${input.value.cursor}`,
    seq: input.value.cursor,
    durableFacts,
    ...input.workspaceId === undefined ? {} : { workspaceId: input.workspaceId },
    ...input.lineage === undefined ? {} : { lineage: input.lineage }
  };
}
function isInjectedContext(data) {
  if (typeof data !== "object" || data === null)
    return false;
  const source = data.source;
  return typeof source === "object" && source !== null && source.kind !== "user";
}

// packages/dsh-bridge/src/host/interaction-broker.ts
function createApprovalBroker() {
  const pending = new Map;
  const resolved = new Set;
  function open(request) {
    const identity = identityFromAudit(request);
    if (identity === undefined || pending.has(identity.correlationId) || resolved.has(identity.correlationId)) {
      return Promise.resolve("unavailable");
    }
    return new Promise((resolve) => {
      const entry = {
        ...identity,
        resolve
      };
      if (request.signal !== undefined) {
        const abort = () => settle(identity.correlationId, "cancelled");
        entry.abort = abort;
        request.signal.addEventListener("abort", abort, { once: true });
      }
      pending.set(identity.correlationId, entry);
    });
  }
  function settle(correlationId, outcome) {
    const entry = pending.get(correlationId);
    if (entry === undefined)
      return;
    pending.delete(correlationId);
    resolved.add(correlationId);
    if (entry.abort !== undefined) {
      entry.abort = undefined;
    }
    entry.resolve(outcome);
  }
  return {
    open,
    list(sessionId) {
      return [...pending.values()].filter((entry) => entry.sessionId === sessionId).map(({ resolve: _resolve, abort: _abort, ...entry }) => entry);
    },
    respond(input) {
      const entry = pending.get(input.correlationId);
      if (entry === undefined) {
        if (resolved.has(input.correlationId))
          throw new Error("INTERACTION_ALREADY_RESOLVED");
        throw new Error("UNKNOWN_INTERACTION");
      }
      if (entry.sessionId !== input.sessionId)
        throw new Error("INTERACTION_SESSION_MISMATCH");
      const outcome = input.decision === "allow" ? "allowed-once" : input.decision === "deny" ? "rejected" : "cancelled";
      settle(input.correlationId, outcome);
      return { outcome };
    },
    dispose() {
      for (const correlationId of [...pending.keys()])
        settle(correlationId, "unavailable");
    }
  };
}
function identityFromAudit(request) {
  const { session } = request.agent;
  let correlationId;
  let turnId;
  for (let seq = session.seq - 1;seq >= 0; seq -= 1) {
    const event = session.eventAt(seq);
    if (correlationId === undefined && event?.type === "approval/asked") {
      const id = event.data?.id;
      if (typeof id === "string" && event.data?.toolName === request.toolName) {
        correlationId = id;
      }
    }
    if (event?.type === "turn/start") {
      const id = event.data?.turnId;
      if (typeof id === "string")
        turnId = id;
      break;
    }
  }
  if (correlationId === undefined)
    return;
  return {
    correlationId,
    sessionId: session.id,
    ...turnId === undefined ? {} : { turnId },
    kind: "approval",
    data: {
      toolName: request.toolName,
      ...request.callId === undefined ? {} : { callId: request.callId },
      ...request.reason === undefined ? {} : { reason: request.reason }
    }
  };
}

// packages/dsh-bridge/src/projections/context-summary.ts
function createContextSummary(input) {
  if (!Number.isSafeInteger(input.maxChars) || input.maxChars < 32) {
    throw new Error("maxChars must be at least 32");
  }
  const header = `DSH ${input.workspaceId}/${input.sessionId} @ ${input.cursor}${input.stale ? " [stale]" : ""}`;
  const lines = [header];
  let omittedFacts = 0;
  for (const fact of input.facts) {
    const line = `${fact.kind}: ${maskSummaryText(fact.text)}`;
    const candidate = `${lines.join(`
`)}
${line}`;
    if (candidate.length > input.maxChars) {
      omittedFacts += 1;
      continue;
    }
    lines.push(line);
  }
  const text = lines.join(`
`).slice(0, input.maxChars);
  return {
    text,
    provenance: {
      source: input.source,
      workspaceId: input.workspaceId,
      sessionId: input.sessionId,
      cursor: input.cursor
    },
    stale: input.stale,
    omittedFacts
  };
}
function maskSummaryText(text) {
  return text.replace(/(?:api[_-]?key|token|secret)\s*[:=]\s*[^\s,;]+/gi, "$1:***").replace(/[A-Za-z]:\\[^\s]+/g, "<path>");
}

// packages/dsh-bridge/src/host/cordis-plugin.ts
var name = "aiohub-dsh-host";
var inject = [...RC1_SERVICE_EVIDENCE];
var HOST_OWNED_CAPABILITIES = [{
  capabilityId: "attachment.limits",
  schemaRevision: 1,
  stability: "stable",
  mode: "read"
}];
var HOST_METHOD_CAPABILITIES = Object.freeze({
  "workspace.list": "workspace.follow",
  "workspace.open": "workspace.follow",
  "workspace.create": "workspace.create",
  "workspace.rename": "workspace.rename",
  "workspace.remove": "workspace.delete",
  "workspace.archiveSession": "workspace.archive-session",
  "session.list": "session.list",
  "session.open": "session.open",
  "session.create": "session.create",
  "session.search": "session.search",
  "session.history": "session.history",
  "session.resume": "session.resume",
  "session.rename": "session.rename",
  "session.restoreArchive": "session.restore-archive",
  "session.delete": "session.delete",
  "session.fork": "session.fork",
  "session.updateQueue": "session.update-queue",
  "session.restart": "session.restart",
  "terminal.open": "terminal.open",
  "terminal.read": "terminal.read",
  "terminal.list": "terminal.open",
  "terminal.input": "terminal.send",
  "terminal.resize": "terminal.resize",
  "terminal.interrupt": "terminal.interrupt",
  "terminal.close": "terminal.close",
  "preset.catalog": "preset.catalog",
  "preset.select": "preset.select",
  "dynamic.host.define": "dynamic.host.define",
  "dynamic.host.run": "dynamic.host.run",
  "dynamic.host.update": "dynamic.host.update",
  "dynamic.host.stop": "dynamic.host.stop",
  "dynamic.host.undefine": "dynamic.host.undefine",
  "dynamic.host.inventory": "dynamic.host.inventory",
  "dynamic.host.diagnostics": "dynamic.host.diagnostics",
  "attachment.limits": "attachment.limits",
  "context.summary": "session.snapshot"
});
function hostMethodCapability(method) {
  return HOST_METHOD_CAPABILITIES[method];
}
function trace(message) {
  if (process.env.AIO_DSH_HOST_DIAGNOSTICS === "1") {
    process.stderr.write(`[aio-dsh-host] ${message}
`);
  }
}
function writeFrame(frame) {
  process.stdout.write(`${JSON.stringify(frame)}
`);
}
function errorData(error) {
  if (error instanceof Error) {
    return { code: error.name || "HOST_ERROR", message: error.message };
  }
  return { code: "HOST_ERROR", message: String(error) };
}
async function apply(ctx) {
  trace("apply entered");
  const adapter = createRc1Adapter({ runtime: { ctx } });
  const negotiated = await adapter.settle();
  trace(`adapter settled with ${negotiated.capabilities.length} capabilities`);
  const host = createDshHost({ adapter });
  host.applyNegotiation(negotiated.capabilities);
  const approvals = createApprovalBroker();
  const unregisterApproval = ctx.on("approval/request", (request) => approvals.open(request));
  const input = createInterface({ input: process.stdin, crlfDelay: Infinity });
  let closed = false;
  async function dispatch(request) {
    const params = request.params ?? {};
    switch (request.method) {
      case "initialize":
        return {
          state: "ready",
          adapter: host.adapterIdentity,
          capabilities: [...host.capabilities(), ...HOST_OWNED_CAPABILITIES]
        };
      case "capabilities":
        return { capabilities: [...host.capabilities(), ...HOST_OWNED_CAPABILITIES] };
      case "workspace.list": {
        const stream = await host.port("workspaces").follow?.(new AbortController().signal);
        if (stream === undefined)
          throw new Error("CAPABILITY_UNAVAILABLE: workspace.follow");
        const first = await stream[Symbol.asyncIterator]().next();
        if (first.done)
          throw new Error("INVALID_WORKSPACE_BASELINE");
        const baseline = first.value;
        if (baseline.type !== "baseline" || baseline.value === undefined) {
          throw new Error("INVALID_WORKSPACE_BASELINE");
        }
        return baseline.value;
      }
      case "workspace.create":
        return await host.port("workspaces").create?.({ path: String(params.path ?? "") });
      case "workspace.open": {
        const baseline = await dispatchHostPort(host, "workspaces", "workspace.follow", "follow", undefined);
        const stream = baseline;
        const first = await stream[Symbol.asyncIterator]().next();
        const workspaceId = String(params.workspaceId ?? "");
        const items = first.value?.value?.items;
        const workspace = items?.find((item) => item.workspaceId === workspaceId);
        if (workspace === undefined)
          throw new Error("UNKNOWN_WORKSPACE");
        return workspace;
      }
      case "workspace.rename":
        return dispatchHostPort(host, "workspaces", "workspace.rename", "rename", params);
      case "workspace.remove":
        return dispatchHostPort(host, "workspaces", "workspace.delete", "delete", params);
      case "workspace.archiveSession":
        return dispatchHostPort(host, "workspaces", "workspace.archive-session", "archiveSession", params);
      case "session.list":
        return { items: await host.port("sessions").list?.() };
      case "session.create":
        return await host.port("sessions").create?.(params);
      case "session.open":
        return await host.port("sessions").open?.({ sessionId: String(params.sessionId ?? "") });
      case "session.search":
        return dispatchHostPort(host, "sessions", "session.search", "search", { query: String(params.query ?? "") });
      case "session.history":
        return dispatchHostPort(host, "sessions", "session.history", "history", params);
      case "session.resume":
        return dispatchHostPort(host, "sessions", "session.resume", "resume", params);
      case "session.rename":
        return dispatchHostPort(host, "sessions", "session.rename", "rename", params);
      case "session.restoreArchive":
        return dispatchHostPort(host, "sessions", "session.restore-archive", "restoreArchive", params);
      case "session.delete":
        return dispatchHostPort(host, "sessions", "session.delete", "delete", params);
      case "session.fork":
        return dispatchHostPort(host, "sessions", "session.fork", "fork", params);
      case "session.updateQueue":
        return dispatchHostPort(host, "sessions", "session.update-queue", "updateQueue", params);
      case "session.restart":
        return dispatchHostPort(host, "sessions", "session.restart", "restart", params);
      case "session.snapshot": {
        const sessionId = String(params.sessionId ?? "");
        const value = await host.port("sessions").snapshot?.({ sessionId });
        const snapshot = createAuthoritativeSnapshot({
          contractHash: String(params.contractHash ?? ""),
          domainGenerationId: String(params.domainGenerationId ?? ""),
          sessionId,
          adapterId: host.adapterIdentity.adapterId,
          releaseCommit: host.adapterIdentity.releaseCommit,
          value
        });
        return { ...snapshot, activeInteractions: approvals.list(sessionId) };
      }
      case "session.submitPrompt": {
        const result = await host.port("sessions").submitPrompt?.(params);
        const sessionId = String(params.sessionId ?? "");
        const agent = ctx.agents?.get(sessionId);
        if (agent === undefined)
          throw new Error(`SESSION_AGENT_UNAVAILABLE: ${sessionId}`);
        agent.whenIdle().catch((error) => {
          trace(`agent ${sessionId} settled with error: ${String(error)}`);
        });
        return result;
      }
      case "session.cancel":
        return await host.port("sessions").cancel?.({ sessionId: String(params.sessionId ?? "") });
      case "terminal.open":
        return dispatchHostPort(host, "terminals", "terminal.open", "open", params);
      case "terminal.read":
        return dispatchHostPort(host, "terminals", "terminal.read", "read", params);
      case "terminal.list":
        return { items: await dispatchHostPort(host, "terminals", "terminal.open", "list", params) };
      case "terminal.input":
        return dispatchHostPort(host, "terminals", "terminal.send", "send", {
          ...params,
          text: String(params.text ?? ""),
          submit: params.submit !== false
        });
      case "terminal.resize":
        return dispatchHostPort(host, "terminals", "terminal.resize", "resize", params);
      case "terminal.interrupt":
        return dispatchHostPort(host, "terminals", "terminal.interrupt", "interrupt", params);
      case "terminal.close":
        return dispatchHostPort(host, "terminals", "terminal.close", "close", params);
      case "preset.catalog":
        return dispatchHostPort(host, "presets", "preset.catalog", "catalog", undefined);
      case "preset.select":
        return dispatchHostPort(host, "presets", "preset.select", "select", params);
      case "dynamic.host.define":
      case "dynamic.host.run":
      case "dynamic.host.update":
      case "dynamic.host.stop":
      case "dynamic.host.undefine":
      case "dynamic.host.inventory":
      case "dynamic.host.diagnostics": {
        const operation = request.method.slice("dynamic.host.".length);
        return dispatchHostPort(host, "dynamicRuntime", request.method, operation, params);
      }
      case "attachment.limits":
        return {
          maxBytes: 10 * 1024 * 1024,
          maxCount: 8,
          mediaTypes: ["image/png", "image/jpeg", "image/webp", "text/plain"],
          provenance: { source: "aio-dsh-host", schemaRevision: 1 }
        };
      case "context.summary": {
        const sessionId = String(params.sessionId ?? "");
        const value = await dispatchHostPort(host, "sessions", "session.snapshot", "snapshot", { sessionId });
        const snapshot = createAuthoritativeSnapshot({
          contractHash: String(params.contractHash ?? ""),
          domainGenerationId: String(params.domainGenerationId ?? ""),
          sessionId,
          adapterId: host.adapterIdentity.adapterId,
          releaseCommit: host.adapterIdentity.releaseCommit,
          value
        });
        return createContextSummary({
          workspaceId: String(params.workspaceId ?? "unknown-workspace"),
          sessionId,
          source: "dsh",
          cursor: snapshot.cursor,
          stale: false,
          facts: snapshot.durableFacts.map((fact) => ({ kind: fact.kind, text: JSON.stringify(fact.data) })),
          maxChars: Number(params.maxChars ?? 4000)
        });
      }
      case "interaction.respond":
        return approvals.respond({
          correlationId: String(params.correlationId ?? ""),
          sessionId: String(params.sessionId ?? ""),
          decision: hostInteractionDecision(params.decision)
        });
      case "shutdown":
        closed = true;
        input.close();
        unregisterApproval();
        approvals.dispose();
        await host.dispose();
        return { state: "stopped" };
      default:
        throw new Error(`UNSUPPORTED_HOST_METHOD: ${request.method}`);
    }
  }
  input.on("line", (line) => {
    trace("request received");
    (async () => {
      let request;
      try {
        request = JSON.parse(line);
        if (typeof request.id !== "number" && typeof request.id !== "string" || typeof request.method !== "string") {
          throw new Error("INVALID_HOST_REQUEST");
        }
        const data = await dispatch(request);
        writeFrame({ id: request.id, type: "result", data });
        if (request.method === "shutdown") {
          ctx.root?.fiber.dispose();
        }
      } catch (error) {
        const id = typeof request === "object" ? request.id : null;
        writeFrame({ id, type: "error", data: errorData(error) });
      }
    })();
  });
  return async () => {
    if (!closed) {
      closed = true;
      input.close();
      unregisterApproval();
      approvals.dispose();
      await host.dispose();
    }
  };
}
async function dispatchHostPort(host, portName, capabilityId, method, input) {
  if (!host.availability(capabilityId).available) {
    throw new Error(`CAPABILITY_UNAVAILABLE: ${capabilityId}`);
  }
  const port = host.port(portName);
  const operation = port[method];
  if (typeof operation !== "function") {
    throw new Error(`CAPABILITY_UNAVAILABLE: ${capabilityId}`);
  }
  return input === undefined ? Reflect.apply(operation, port, []) : Reflect.apply(operation, port, [input]);
}
function hostInteractionDecision(value) {
  if (value === "allow" || value === "deny" || value === "cancel" || value === "timeout")
    return value;
  throw new Error("INVALID_INTERACTION_DECISION");
}
export {
  name,
  inject,
  hostMethodCapability,
  apply
};
